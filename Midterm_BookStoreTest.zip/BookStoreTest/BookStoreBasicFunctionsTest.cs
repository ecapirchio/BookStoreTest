using BookStore;
using Xunit;

namespace BookStoreTest
{
    public class BookStoreBasicFunctionsTest
    {
        [Fact]
        public void GetBookByIdTest()
        {
            var result = BookStoreBasicFunctions.GetBookById(2167);
            Assert.True(result.BookTitle == "Farid");
            Assert.True(result.YearOfRelease == 2000);
        }

        [Fact]
        public void GetBookByTitleTest()
        {
            var result = BookStoreBasicFunctions.GetBookByTitle("Farid");
            Assert.True(result.BookTitle == "Farid");
            Assert.True(result.YearOfRelease == 2000);
        }

        [Fact]
        public void GetBookByAuthorTest()
        {
            var result = BookStoreBasicFunctions.GetBooksByAuthorLastName("Chaucer");
            Assert.True(result.Count > 0, "Expected at least one book by 'Chaucer' in the database.");
        }

        [Fact]
        public void GetAllBooks()
        {
            var result = BookStoreBasicFunctions.GetAllBooks();
            Assert.True(result.Count == 3);
        }

        [Fact]
        public void GetAllCheckedOutBooks()
        {
            var result = BookStoreBasicFunctions.GetAllCheckedOutBooks();
            Assert.True(result.Count == 1);
        }
    }
}