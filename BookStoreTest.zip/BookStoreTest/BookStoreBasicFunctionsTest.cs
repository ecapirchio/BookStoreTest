using BookStore;
using Xunit;

namespace BookStoreTest
{
    public class BookStoreBasicFunctionsTest
    {
        [Fact]
        public void GetMovieByIdTest()
        {
            var result = BookStoreBasicFunctions.GetBookById(2167);
            Assert.True(result.BookTitle == "Farid");
            Assert.True(result.YearOfRelease == 2000);
        }

        [Fact]
        public void GetAllMovies()
        {
            var result = BookStoreBasicFunctions.GetAllBooks();
            Assert.True(result.Count == 3);
        }

        [Fact]
        public void GetAllCheckedOutMovies()
        {
            var result = BookStoreBasicFunctions.GetAllCheckedOutBooks();
            Assert.True(result.Count == 1);
        }
    }
}